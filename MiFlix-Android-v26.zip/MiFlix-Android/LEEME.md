# MiFlix para Android

## 1. Crear el proyecto de Firebase (gratis)
1. Entra a https://console.firebase.google.com y crea un proyecto.
2. Build > Authentication > Comenzar > activa **Correo electrónico/contraseña**.
3. Build > Firestore Database > Crear base de datos (modo producción).
4. En la pestaña **Reglas** de Firestore pega el contenido de `firestore.rules` y publica.
5. Configuración del proyecto > Tus apps > Web (</>) > registra la app y copia `firebaseConfig`.
6. Pega esos valores en `app/src/main/assets/index.html` (zona "PEGA AQUÍ").

## 2. Compilar el APK
- GitHub: sube el ZIP a la raíz del repositorio; tu flujo "Crear APK" lo descomprime y compila solo.
- Android Studio: abre la carpeta y elige Build > Build APK(s).

## 3. Ser administrador
1. Abre la app y crea tu cuenta (usuario y contraseña).
2. En Firebase > Authentication > Usuarios copia tu **UID**.
3. En Firestore crea la colección `admins` con un documento cuyo ID sea ese UID (agrega cualquier campo, p. ej. `ok: true`).
4. Cierra sesión y vuelve a entrar: verás "+ Agregar", Editar y Eliminar. Los demás usuarios solo ven y califican.

## 5. Perfiles de usuario
- Cada usuario tiene perfil: toca tu foto (arriba a la derecha) para subir, cambiar o quitar tu imagen.
- Todos pueden ver los perfiles desde la fila **Comunidad** o tocando a quien calificó un título.
- Las fotos se guardan (reducidas a 256×256) en Firestore, colección `users`; no necesitas Firebase Storage.
- **Importante:** vuelve a pegar `firestore.rules` en Firebase > Firestore > Reglas y publica, o las fotos no se podrán guardar.

## 6. Ver juntos
- En un título (o en un capítulo, botón 👥) toca **Ver juntos**: se crea una sala con un código de 5 letras.
- Invita a un amigo desde la sala o desde su perfil (Comunidad), o dale el código: él lo escribe en el botón 🎬 de arriba.
- Cada uno usa su reproductor nativo; play, pausa y saltos se sincronizan entre los dos.
- **Importante:** vuelve a publicar `firestore.rules` (ahora incluye `rooms`).

## 7. Amigos, chat y voz
- Agrega amigos desde su perfil (Comunidad) o desde el botón de chat del encabezado. El otro acepta la solicitud.
- Chat privado: botón de chat > toca a tu amigo.
- Mientras ven algo juntos, en el reproductor aparecen **Chat** (pestañas Sala / Privado / Voz) y **Voz** (micrófono en vivo).
- **Importante:** vuelve a publicar `firestore.rules` (incluye `friendships`, `chats` y subcolecciones de `rooms`).

## 8. Novedades (chat flotante, likes, cifrado, recuperación)
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nuevas colecciones `likes`, `imgs`, `secrets`, `recovery` y mensajes privados cifrados).

- **Chat al ver juntos (horizontal):** el botón *Chat* abre una mini ventana flotante con avatar + mensaje. Con el chat cerrado, cada mensaje nuevo aparece arriba a la derecha (avatar, nombre y mensaje en una línea; si es largo termina en "…" y tocándolo se abre el chat).
- **Vertical:** al girar el teléfono el video queda arriba y el chat se abre solo debajo (con Sala / Privado / Voz). Al volver a horizontal vuelve el video completo.
- **Likes:** botón ♡ en cada título. El perfil muestra las portadas de lo que le diste like.
- **Imágenes originales:** las portadas y fotos de perfil se suben sin reducir (máx. 15 MB) y se guardan por partes en Firestore (`imgs`). En listas se usa una miniatura para que cargue rápido; al abrir el título o el perfil se carga la original (toca la imagen para ampliarla).
- **Chats privados cifrados de extremo a extremo** (ECDH P-256 + AES-GCM). La clave privada vive en tu teléfono y una copia protegida con tu contraseña en `secrets/{tu uid}`; los mensajes antiguos sin cifrar se siguen viendo. Ambos amigos deben abrir la app actualizada una vez para activarlo.
- **Edad + pregunta de seguridad** al crear cuenta (*¿Quién es tu persona o mascota favorita?*). Los usuarios ya existentes verán un aviso para completarlo.
- **Código de recuperación único** (20 caracteres): se muestra una sola vez al crear la cuenta. En el login, *¿Perdiste el acceso?* → usuario + código + respuesta (+ nueva contraseña opcional). Todo se verifica en el teléfono: la contraseña se guarda cifrada con (código + respuesta), así nadie —ni tú como administrador— puede leerla.

## 9. Imágenes optimizadas y caché local
**Vuelve a publicar `firestore.rules`** (nueva colección `meta`).

- **Imágenes:** se convierten a WebP al 85 % con lado mayor máximo de 1600 px (1024 px en fotos de perfil). Casi no se nota la diferencia y pesan 5 a 10 veces menos. Las miniaturas de las listas son de 400 px (256 px en avatares). GIF y fotos ya pequeñas (<300 KB) se suben tal cual.
- **Caché en el teléfono (IndexedDB):** la primera vez se descarga el catálogo y, en segundo plano, las imágenes originales. Las siguientes veces la app abre al instante desde el teléfono y solo pide lo **nuevo o editado** (`updatedAt`) y los títulos eliminados (`meta/catalog`).
- Los títulos que ya existían se descargan completos una vez; al editarlos reciben `updatedAt` y entran en la sincronización incremental.
- Si borras los datos de la app, se vuelve a descargar todo una vez.

## 10. Subtítulos
**No necesitas republicar nada para esto**, pero sí vuelve a compilar el APK (se agregó la librería de traducción de Google ML Kit).

- **Elegir idioma:** al abrir un título aparece el cuadro *Subtítulos* con dos opciones: el idioma de los subtítulos (o *Desactivados*) y el **idioma original del audio**. Se guardan en el teléfono y se usan en todo lo que reproduzcas (también en *Ver juntos*: cada persona usa su propio idioma).
- **Detección desde el enlace**, en este orden:
  1. Subtítulos incluidos en el video (HLS `.m3u8` o archivos `.mp4`/`.mkv` con pistas).
  2. Subtítulos que la página del enlace declare (`<track>`) o descargue (`.vtt`, `.srt`, `.ass`, `.ttml`).
  3. Archivos "hermanos" junto al video: `pelicula.mp4` → `pelicula.vtt` / `pelicula.srt` (también `pelicula.es.vtt`).
  Si hay uno en el idioma elegido se activa solo.
- **Si no hay subtítulos en tu idioma** se crean automáticamente (beta): la app toma el audio que suena, lo reconoce con el reconocimiento de voz del teléfono (en el idioma original que elegiste) y lo traduce en el teléfono al idioma de los subtítulos. Requisitos: **Android 13 o superior**, internet, y aceptar el permiso de micrófono la primera vez (solo se usa para el reconocimiento; no se graba nada). La primera vez de cada par de idiomas descarga el modelo de traducción (~30 MB).
- **Botón CC** en el reproductor (arriba, junto a *Calidad*): apaga los subtítulos, elige otra pista o fuerza los automáticos. Muestra ✓ cuando hay subtítulos activos.
- Los subtítulos automáticos salen unos instantes después de lo que se dice y no son perfectos; es normal en esta versión.

## 11. Reportes de bugs y sugerencias
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nueva colección `feedback`).

- Todos los usuarios ven al final de la pantalla principal el botón **💡 Bug o sugerencia**: eligen tipo, escriben el mensaje y lo envían. También ven el estado de sus envíos (Pendiente / Resuelto).
- Cada reporte guarda usuario, tipo, texto, fecha y datos del dispositivo (para poder reproducir el bug).
- **El administrador** ve además el botón **📥 Reportes (n)** con todos los envíos, filtros (Pendientes / Resueltos / Todos), y puede marcarlos como resueltos, reabrirlos o eliminarlos. Los demás usuarios solo ven los suyos.

## 12. Salas: quién está, públicas, YouTube y video más largo
**IMPORTANTE: vuelve a publicar `firestore.rules`** (nueva subcolección `rooms/{código}/presence` y el campo `public` de las salas) y vuelve a compilar el APK.

- **Chat:** ya no se ve gigante al entrar (el chat nace con su tamaño final y se ignora el tamaño de letra del sistema). Los mensajes nuevos salen **abajo**: en vertical el campo de escribir queda abajo; en la ventanita horizontal se queda arriba para que el teclado no lo tape.
- **Quién está en la sala:** barra *👥 N personas en la sala* arriba del chat (tócala para ver la lista). Cuando alguien entra o sale aparece una línea en el chat y un aviso. Si alguien cierra la app de golpe, se marca como salido en ~1 minuto.
- **Salas públicas:** al crear una sala marca *Sala pública*. En el botón de salas (🎬) aparece la lista de salas públicas abiertas, con *Entrar* sin código ni invitación.
- **YouTube juntos:** en el botón de salas → *Elegir video de YouTube* (navegas YouTube y tocas *Ver juntos este video*) o pegas un enlace. Desde la versión 13 se reproduce con el **reproductor oficial incrustado de YouTube** (como Rave), ya no con enlaces extraídos, y se sincroniza play, pausa y saltos. Hay chat, voz y lista de personas igual que antes (en horizontal el chat queda a un lado).
  - Algunos videos no permiten reproducirse fuera de YouTube (el dueño bloqueó la incrustación, errores 101/150/152/153). Rave tiene la misma limitación; la app avisa y hay que elegir otro video.
- **Video más largo:** si la página del enlace tiene varios videos (tráilers, avances, recomendados), la app junta los que aparecen durante unos 2 a 6 segundos, mide cuánto dura cada uno y reproduce el más largo. Si solo hay uno, se abre igual (tarda ~2 s más que antes).


## 13. Comentarios, idioma de la app, versiones y cierre de salas
**IMPORTANTE: vuelve a publicar `firestore.rules`** (comentarios en `titles/{id}/comments`, campos `alive` y `closed` en las salas) y vuelve a compilar el APK.

- **Comentarios:** al abrir una película o serie, abajo hay una sección *Comentarios*. Cada quien puede borrar los suyos; el administrador puede borrar cualquiera. Máximo 500 caracteres.
- **Idioma de la app:** botón ⚙ (arriba, junto a salir) → *Español / English*. Traduce la interfaz y los avisos del reproductor. El contenido que subes (títulos, sinopsis) no se traduce. Al cambiar, la pantalla se recarga.
- **Versiones por idioma / subtítulos (administrador):** al agregar o editar una película o un capítulo, escribe un nombre para el enlace principal (ej. *Latino*) y usa **+ Versión** para añadir más enlaces (ej. *Inglés + sub ES*). Si hay más de una versión, al tocar ▶ aparece *Elige una versión*. En *Ver juntos*, **cada persona elige la suya** al entrar a la sala (el anfitrión al pulsar *Empezar a ver*); la sincronización es por tiempo, así que las versiones deben durar lo mismo.
- **Salas que se cierran solas (sin latidos, gasto mínimo de Firestore):** no se envía ninguna señal mientras hay gente. Solo cuando **la última persona sale**, la app manda **una sola señal** (`emptyAt`, junto con borrar su presencia) y la sala se borra a los **10 segundos** si nadie vuelve a entrar. Si alguien entra dentro de esos 10 s, la señal se cancela. El anfitrión que cierra la pantalla de invitación sin empezar también cuenta como sala vacía. Una sala cerrada desaparece de la lista pública y al intentar entrar dice *Esa sala ya se cerró*.
  - Gasto por persona y sesión: ~2 escrituras al entrar (presencia + registro en la sala, y este último solo si es la primera vez) y 1 al salir. Antes había una escritura cada 3 s por persona.
  - También se redujo: la presencia ya no se renueva cada 20 s, la voz ya no se renueva cada 30 s, el anfitrión ya no reenvía la posición cada 15 s (ahora cada 2 min y solo reproduciendo; en YouTube, nunca), y los saltos o pausas seguidos se agrupan en una sola escritura.
  - Limitación: si la app se cierra a la fuerza (sin pasar por el cierre normal), no puede avisar que salió. Esa sala se limpia sola a las 6 horas, o antes si alguien que sí salió normalmente era el último.

## 14. Géneros y botón de opciones
- **Botón ⚙ de opciones:** ahora es un botón flotante en la esquina inferior derecha. La cabecera ya no se sale de la pantalla (se acabó el desplazamiento lateral).
- **Géneros (administrador):** al agregar o editar contenido aparece *Géneros*: toca los que apliquen (se pueden varios). Vienen Acción, Aventura, Comedia, Drama, Terror, Suspenso, Romance, Ciencia ficción, Fantasía, Animación, Misterio, Crimen, Documental, Familiar, Marvel y DC. Para crear uno nuevo, escríbelo en *Nuevo género…* y pulsa *Agregar*: queda guardado para futuros títulos (documento `meta/genres`, no requiere cambiar las reglas).
- **Menú de categorías:** en el inicio hay una barra con *Todos* y los géneros que tengan al menos un título. Al tocar uno se ven todos los títulos de ese género (películas, series, anime…). La ficha de cada título muestra sus géneros.
- Los títulos ya subidos no tienen género: edítalos y marca los que correspondan.

## 15. Quitar géneros y fila de videos en YouTube juntos
**Vuelve a publicar `firestore.rules`** (la sala ahora guarda `queue` y `qi`).

- **Quitar géneros (administrador):** en el formulario de contenido, junto a *Géneros* pulsa **Editar lista**. Cada género aparece con ✕; tócalo y confírmalo pulsando otra vez. Se quita de la lista (incluso los que vienen de fábrica) y de todos los títulos que lo tengan. Pulsa **Listo** para volver a elegir géneros. Lo demás que añadas mal ya se podía quitar: episodios (✕), temporadas (*Quitar*), versiones (✕), títulos (*Eliminar*) y comentarios (*Borrar*).
- **Fila en YouTube juntos:** en una sala de YouTube aparece la pestaña **Fila**. Ahí cualquiera de la sala puede:
  - **🔍 Buscar en YouTube:** abre YouTube; entra a un video y pulsa *Agregar a la fila*. Se queda abierto para agregar varios; cierra con ✕ o atrás.
  - **Pegar un enlace** y pulsar *Agregar*.
  - **Saltar** tocando un video de la lista, o con ⏮ / ⏭. Todos cambian al mismo video.
  - **Quitar** un video con ✕ (siempre queda al menos uno).
  - Al terminar un video pasa solo al siguiente; si uno no se puede reproducir fuera de YouTube, lo salta.
- Gasto: agregar, saltar o quitar es 1 escritura. Además se evitan escrituras repetidas cuando el estado de reproducción no cambió.

## 16. Búsqueda, recuperar cuenta visible y ver el código de recuperación
**Vuelve a publicar `firestore.rules`** (la colección `secrets` ahora acepta `rcw`).

- **Búsqueda:** botón 🔍 en la esquina inferior derecha, encima de ⚙. Busca por título, género o tipo (sin importar mayúsculas ni acentos); al tocar un resultado se abre su ficha.
- **Recuperar cuenta:** en la pantalla de entrada y de crear cuenta hay un botón **Recuperar cuenta** siempre visible. Si el usuario o la contraseña fallan al entrar, aparece además un aviso que lo señala.
- **Ver el código otra vez:** ⚙ Opciones → *Código de recuperación* → escribe tu contraseña → *Ver mi código*. El código se guarda cifrado con tu contraseña (campo `rcw` en `secrets/{uid}`), nunca en claro.
  - Las cuentas creadas **antes** de esta versión no tienen el código guardado (antes no se almacenaba). Para ellas, la misma pantalla ofrece **Generar código nuevo** (pide la respuesta a la pregunta de seguridad); el código anterior deja de servir.
  - Si alguien recupera su cuenta con su código, ese código también queda guardado para poder verlo después.

## 17. Corrección: botones flotantes
🔍 y ⚙ ahora quedan fijos en la esquina inferior derecha (⚙ abajo, 🔍 encima) en todo momento, sin tener que bajar hasta el final de la pantalla. Antes una regla de estilo los dejaba dentro del flujo de la página, alineados a la izquierda.


## 18. Carrusel del inicio y salas que no se pausan al salir
**No necesitas republicar `firestore.rules`.** Vuelve a compilar el APK.

- **Carrusel:** la imagen grande de arriba muestra las **últimas 5 películas añadidas**. Cambia sola cada **5 segundos**, y también puedes **deslizar con el dedo** a izquierda o derecha para ver las anteriores sin esperar (al mover a mano, el conteo de 5 s vuelve a empezar). Los puntitos de abajo indican cuál es. Tocar una abre su ficha. Si no hay películas, usa los últimos 5 títulos.
- **Salas privadas:** ya se cerraban solas igual que las públicas (una sola señal `emptyAt` cuando sale la última persona y borrado a los 10 s; también si el anfitrión cierra la invitación sin empezar), así que no se cambió nada.
- **Salir ya no pausa a los demás (películas, series y YouTube):** la pausa que se hacía al cerrar el reproductor se enviaba a la sala. Ahora la pausa al salir o al pasar la app a segundo plano es solo local. Al volver, te sincronizas con lo que sigue sonando en la sala.
- **Fila de YouTube sin interrupciones:** mientras abres el buscador para agregar videos, el video sigue reproduciéndose y escuchándose. El buscador ya no puede reproducir nada (así no le quita el audio) y, si el sistema pausa el video, se reanuda solo. Agregar o quitar videos de la fila ya no reenvía el estado anterior de reproducción.


## 19. Panel de la sala de YouTube plegable y actualizaciones desde la app
**No necesitas republicar `firestore.rules`** (`meta/update` ya la cubre la regla de `meta`, solo el administrador escribe). Vuelve a compilar el APK.

- **Panel de chat / voz / fila (horizontal):** ahora empieza **cerrado** y el video ocupa toda la pantalla. Un botón flotante 💬 al borde derecho (discreto, semitransparente) lo abre; la ✕ del panel o el botón atrás lo cierran. Con el panel cerrado, los mensajes nuevos suman un contador en el botón (💬 2) y aparecen en un aviso corto. En vertical todo queda como antes (video arriba, panel abajo).
- **Actualizaciones:**
  1. Compila el APK nuevo (misma llave `miflix.jks`, así se instala encima) y súbelo a un enlace **https directo**, por ejemplo un *Release* de GitHub (Releases → Draft a new release → adjunta el `.apk` → copia el enlace del archivo).
  2. En la app, como administrador: ⚙ Opciones → *Publicar actualización*. Escribe el **número de versión** (la «N» de 1.N; la app te sugiere la siguiente), pega el enlace y, si quieres, las novedades. Pulsa *Publicar*.
  3. Cada usuario, al abrir la app, ve **«Nueva actualización»** con las novedades. Al tocar **Descargar** se baja el APK con barra de progreso y se abre el instalador de Android. La primera vez Android pedirá permitir instalar desde MiFlix (la app te lleva a ese ajuste y continúa sola al volver).
  4. También pueden usar ⚙ Opciones → *Buscar actualización* cuando quieran.
  - El APK no se guarda en Firestore (pesa demasiado para la base de datos); solo se guarda el aviso (`meta/update`). La app comprueba que el archivo sea de MiFlix antes de instalar, y Android rechaza cualquier APK firmado con otra llave.


## 20. Actualizaciones con enlace de Google Drive
- Puedes pegar el enlace normal de Drive («Cualquiera con el enlace», el que termina en /view): la app lo convierte sola en descarga directa, tanto al publicar como al descargar.
- **El número de versión debe ser MAYOR que el instalado** y coincidir con el número de compilación real del APK (la «N» de 1.N, el «#N» de la ejecución en GitHub Actions). Si no, «Buscar actualización» dice que ya tienes la última.
- «Buscar actualización» ahora muestra también qué versión está publicada.


## 21. Categorías deslizables y pantalla gris al salir de una película
- Las categorías (géneros) del menú principal ahora son **una sola fila** que se desliza con el dedo de derecha a izquierda, en vez de acumularse hacia abajo. Al tocar una, la fila conserva su posición.
- Al volver del reproductor la pantalla ya no se queda gris: la pantalla principal no se recrea al girar (`configChanges`) y se le fuerza un repintado al volver.

## Mejorar imagen (v23)
En el reproductor hay un botón **Mejorar** (Apagado / Suave / Fuerte) que aplica un filtro de nitidez en la GPU
(`Enhance.kt`, Media3 Effects). No se aplica a videos de YouTube. Si el teléfono no lo soporta, se apaga solo.

## Subtítulos de la página (v22)
MiFlix toma los subtítulos que ya trae la página (<track>, peticiones .vtt/.srt/.ass, JW Player, Video.js, URLs en el código)
y los usa antes que los automáticos. Los automáticos solo se crean si no hay ninguno.
Modo **Fuerte**: reescalado bicúbico (Catmull-Rom) hasta ×2 (máx. ~1080 px de alto) + nitidez. Modo **Suave**: solo nitidez.

## 11. Cambios de esta versión
- **Inicio:** el carrusel superior muestra lo último añadido de cualquier tipo (películas, series, anime, otros). Las series rotan por temporada (foto + nombre) cada 5 s.
- **Temporadas:** al agregar/editar una serie o anime, cada temporada tiene nombre y foto opcionales (se ven en el carrusel, en las pestañas y en el detalle).
- **Idioma:** se quitaron los selectores de subtítulos/audio por defecto del detalle. Solo aparecen las versiones que tú agregaste (si hay una sola, se reproduce directo). Los subtítulos incrustados siguen funcionando igual.
- **Reproductor:** corregido el fallo al avanzar/retroceder con toques seguidos (los saltos se suman y se ejecuta uno solo; ya no rebotan con la sala).
- **Enlace directo (opción aparte):** el enlace que tú pones NO se modifica y la app funciona igual que siempre. Cuando la app encuentra el video real de la página, el administrador lo guarda aparte (campos `dr`/`drs` del título, capítulo o versión). Se ve en Editar como "Enlace directo detectado". En la **versión web** (navegador), si existe, ▶ Reproducir usa ese enlace en un reproductor integrado (con respaldo "Abrir enlace original"). Si cambias el enlace original, el directo guardado se ignora hasta que la app vuelva a detectarlo.
