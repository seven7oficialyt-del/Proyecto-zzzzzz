package com.miflix.app

import java.lang.ref.WeakReference

/**
 * Cuando el buscador de video (PlayerActivity) encuentra el enlace directo de una página,
 * se lo entrega a la pantalla principal para que la web lo guarde en lugar del enlace original.
 */
object Resolved {
    @Volatile var pending: Pair<String, String>? = null
    @Volatile var main: WeakReference<MainActivity>? = null

    fun deliver(orig: String, direct: String) {
        if (orig.isBlank() || direct.isBlank() || orig.substringBefore('#') == direct.substringBefore('#')) return
        pending = Pair(orig, direct)
        main?.get()?.pushResolved()
    }
}
